#include <iostream>
#include <vector>
#include <fstream>
#include <random>
#include <numeric>

int main() {
    constexpr int time_steps = 50;
    constexpr int window_size = 5;
    double x_true = 0.0;
    
    std::default_random_engine generator;
    std::normal_distribution<double> dist(0.0, 2.0);

    std::vector<double> observations;
    std::ofstream data_file("filter_results.csv");

    if (!data_file) {
        std::cerr << "Error opening file!\n";
        return 1;
    }

    data_file << "t,True_State,Noisy_Observation,Estimated_State\n";

    for (int t = 0; t <= time_steps; ++t) {
        double z_t = x_true + dist(generator);
        observations.push_back(z_t);

        double x_est = 0.0;
        if (observations.size() < window_size) {
            x_est = std::accumulate(observations.begin(), observations.end(), 0.0) / observations.size();
        } else {
            x_est = std::accumulate(observations.end() - window_size, observations.end(), 0.0) / window_size;
        }

        data_file << t << "," << x_true << "," << z_t << "," << x_est << "\n";

        x_true += 1.0;
    }

    std::cout << "Success! Results saved to filter_results.csv\n";

    return 0;
}
