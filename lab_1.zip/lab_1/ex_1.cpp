#include <iostream>
#include <fstream>

int main() {
    constexpr int time_steps = 50;
    double x = 0.0;
    
    std::ofstream data_file("state_data.csv");
    
    if (!data_file) {
        std::cerr << "Error opening file!\n";
        return 1;
    }

    data_file << "t,x_t\n";

    for (int t = 0; t <= time_steps; ++t) {
        data_file << t << "," << x << "\n";
        x += 1.0;
    }

    std::cout << "Success! Data for 50 steps saved to state_data.csv\n";

    return 0;
}
