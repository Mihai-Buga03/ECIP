#include <iostream>
#include <vector>
#include <fstream>
#include <random>
#include <algorithm>

int main() {
    constexpr int time_steps = 50;
    constexpr int window_size = 10;
    double x_true = 0.0;
    
    std::default_random_engine generator;
    std::normal_distribution<double> noise_dist(0.0, 2.0);

    std::vector<double> observations;
    std::ofstream data_file("analysis_results.csv");

    if (!data_file) {
        std::cerr << "Error: Could not create data file.\n";
        return 1;
    }

    data_file << "t,True_State,Observation,MA_Estimate\n";

    for (int t = 0; t <= time_steps; ++t) {
        double z_t = x_true + noise_dist(generator);
        observations.push_back(z_t);

        double x_est = 0.0;
        int current_size = observations.size();
        int start_idx = std::max(0, current_size - window_size);
        int count = current_size - start_idx;

        double sum = 0.0;
        for (int i = start_idx; i < current_size; ++i) {
            sum += observations[i];
        }
        x_est = sum / count;

        data_file << t << "," << x_true << "," << z_t << "," << x_est << "\n";

        x_true += 1.0;
    }

    std::cout << "Simulation Finished. File 'analysis_results.csv' generated.\n";

    return 0;
}