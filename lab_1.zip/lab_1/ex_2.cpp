#include <iostream>
#include <fstream>
#include <random>

int main() {
    constexpr int time_steps = 50;
    double x_true = 0.0;

    std::default_random_engine generator;
    std::normal_distribution<double> noise(0.0, 2.0);

    std::ofstream data_file("noisy_state.csv");

    if (!data_file) {
        std::cerr << "Error opening file!\n";
        return 1;
    }

    data_file << "t,True_State,Noisy_Measurement\n";

    for (int t = 0; t <= time_steps; ++t) {
        data_file << t << "," << x_true << "," << x_true + noise(generator) << "\n";
        x_true += 1.0;
    }

    std::cout << "Simulation complete. Data saved to noisy_state.csv\n";

    return 0;
}
